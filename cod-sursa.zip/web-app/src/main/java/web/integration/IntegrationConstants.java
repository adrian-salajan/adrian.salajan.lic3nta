package web.integration;

public class IntegrationConstants {
	
	public static final String PRICE_UPDATED = "pu";
	public static final String QTY_UPDATED = "qy";
	public static final String NOT_UPDATED = "nu";
}
