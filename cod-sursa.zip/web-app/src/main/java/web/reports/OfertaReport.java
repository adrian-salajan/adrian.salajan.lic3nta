package web.reports;

public class OfertaReport {
	
	private long cid;
	private String client;
	private String judet;
	private String adresa;
	
	public long getCid() {
		return cid;
	}
	public void setId(long cid) {
		this.cid = cid;
	}
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public String getJudet() {
		return judet;
	}
	public void setJudet(String judet) {
		this.judet = judet;
	}
	public String getAdresa() {
		return adresa;
	}
	public void setAdresa(String adresa) {
		this.adresa = adresa;
	}
	
	

}
