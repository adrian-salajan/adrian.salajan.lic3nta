package web.mvc.model;

public class OrderView {
	
	int qty;
	long productId;

}
