package web.mvc.model;

import javax.validation.constraints.AssertTrue;


public class ProductOrdered {
	
	private Product product;
	
	int qty;
	
	@AssertTrue(message="Unavailable.")
	public boolean isQuantityValid() {
		return (qty >= 0) && (qty <= product.getStock());
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((product == null) ? 0 : product.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductOrdered other = (ProductOrdered) obj;
		if (product == null) {
			if (other.product != null)
				return false;
		} else if (!product.equals(other.product))
			return false;
		return true;
	}
	
	

	
	

}
